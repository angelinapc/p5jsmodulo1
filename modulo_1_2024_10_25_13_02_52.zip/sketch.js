function setup() {
  createCanvas(1000, 1000); //criando o cenário
  background("white"); //cor do cenário
}

function draw() { //função de desenhar

  stroke("rgb(88,0,88)"); //cor do contorno do quadrado
  fill("rgb(156,0,112)"); //cor do quadrado

  if (mouseIsPressed) { //'quando o mouse for presionado' o quadrado aparece
    rect(mouseX, mouseY, 50, 50); //posição e tamanho do quadrado - mouseX e mouseY é para a figura seguir o ponteiro do mouse
  }
}
